# Bulk 16 — Phone-only build

This project is a native Android workout companion for the supplied 16-week dumbbell bulk program.

## Features in this build
- 16-week automatic program
- Daily workout weight setup before each workout
- Weight fields are saved per exercise and prefilled into set logs
- Set-by-set kg/reps/RIR logging
- Rest timer
- Exercise form guides with stance, execution, checkpoints, mistakes, target muscles and safety cues
- Progress and nutrition screens

## GitHub Actions
The included `.github/workflows/build-apk.yml` extracts this archive, copies the project to the workspace, and builds a debug APK.
